function basicFun () {
alert("Hello World")

}

basicFun ();