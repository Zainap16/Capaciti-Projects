

var Ret = lefty ("This is a test",7);
alert(Ret);

function lefty (InStr,Num){

var OutStr= InStr.substring (InStr,Num);
alert(OutStr);

}

lefty("This is a test",7);