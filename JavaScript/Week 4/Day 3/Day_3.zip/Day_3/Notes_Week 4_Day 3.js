//None of my code works currently

//Due date is too close for me to care.

/*
What even is code?

Working code is now a social construct.
*/